import java.util.HashSet;
import java.util.Random;

public class User {
    private String name;
    private String userId;
    private String password;
    private HashSet<String> friends;

    public User(String name, String password) {
        this.name = name;
        this.userId = generateUserId();
        this.password = password;
        this.friends = new HashSet<>();
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public HashSet<String> getFriends() {
        return friends;
    }

    private String generateUserId() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder userIdBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            userIdBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }
        return userIdBuilder.toString();
    }
}
