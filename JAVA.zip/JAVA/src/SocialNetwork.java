import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class SocialNetwork {
    private HashMap<String, User> users;
    private HashMap<String, HashSet<String>> connections;

    public SocialNetwork() {
        users = new HashMap<>();
        connections = new HashMap<>();
    }

    public void createUser(String name, String password) {
        User newUser = new User(name, password);
        users.put(newUser.getUserId(), newUser);
        connections.put(newUser.getUserId(), newUser.getFriends());
        System.out.println("Account created successfully. Your user ID is: " + newUser.getUserId());
    }


    public void connectWithFriend(String userId, String friendId) {
        User user = users.get(userId);
        User friend = users.get(friendId);
        if (user != null && friend != null) {
            user.getFriends().add(friendId);
            friend.getFriends().add(userId);
            System.out.println("Connected with " + friend.getName() + " (ID: " + friendId + ")");
        } else {
            System.out.println("User or friend not found.");
        }
    }

    public void showFriendsList(String userId) {
        HashSet<String> friends = connections.get(userId);
        if (friends != null) {
            System.out.println("Friends List:");
            for (String friendId : friends) {
                User friend = users.get(friendId);
                System.out.println(friend.getName() + " (ID: " + friendId + ")");
            }
        } else {
            System.out.println("No friends yet.");
        }
    }

    public static void main(String[] args) {
        SocialNetwork socialNetwork = new SocialNetwork();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nSocial Network Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. Find and Connect with Friends");
            System.out.println("3. Show Friends List");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter your name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter your password: ");
                    String password = scanner.nextLine();
                    socialNetwork.createUser(name, password);
                    break;
                case "2":
                    System.out.print("Enter your user ID: ");
                    String userId = scanner.nextLine();
                    System.out.print("Enter the friend's user ID: ");
                    String friendId = scanner.nextLine();
                    socialNetwork.connectWithFriend(userId, friendId);
                    break;
                case "3":
                    System.out.print("Enter your user ID to see friends: ");
                    String userToView = scanner.nextLine();
                    socialNetwork.showFriendsList(userToView);
                    break;
                case "4":
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
